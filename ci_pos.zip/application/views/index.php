    <div class="jumbotron">
        <div class="container">
          <h1>Welcome, <?php echo $first_name; ?>!</h1>
          <p>Your are now inside the application</p>
        </div>
    </div> 
